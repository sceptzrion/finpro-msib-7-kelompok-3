function loadPage(page) {
    let content = "";
    switch (page) {
        case "beranda":
            content = `
                <h1>Selamat Datang di Dashboard Siswa</h1>
                <div class="dashboard-grid">
                    <div class="card">
                        <div class="card-title">
                            <i class="fas fa-book"></i> Kursus yang Diikuti
                        </div>
                        <div class="course-list">
                            <div class="course-item">
                                <div>Matematika</div>
                                <div class="progress-bar">
                                    <div class="progress" style="width: 75%"></div>
                                </div>
                            <div class="course-details">
                                <span>75% Selesai</span>
                                <a href="#" class="btn-small" onclick="loadPage('kursus-matematika')">Lanjutkan</a>
                            </div>
                            </div>
                            <div class="course-item">
                                <div>Bahasa Inggris</div>
                                <div class="progress-bar">
                                    <div class="progress" style="width: 60%"></div>
                                </div>
                                    <div class="course-details">
                                    <span>60% Selesai</span>
                                <a href="#" class="btn-small" onclick="loadPage('kursus-bahasa-inggris')">Lanjutkan</a>
                            </div>
                            </div>
                            <div class="course-item">
                                <div>Pemrograman Web</div>
                                <div class="progress-bar">
                                    <div class="progress" style="width: 40%"></div>
                                </div>
                                <div class="course-details">
                                    <span>40% Selesai</span>
                                    <a href="#" class="btn-small" onclick="loadPage('kursus-pemrograman-web')">Lanjutkan</a>
                                </div>
                            </div>
                            <a href="#" class="btn-link centered" id="link-kursus">Lihat Semua Kursus</a>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-title">
                            <i class="fas fa-tasks"></i> Tugas Mendatang
                        </div>
                        <div class="task-list">
                            <div class="task-item">
                                <div>Quiz Matematika</div>
                                <div class="deadline">2 hari lagi</div>
                            </div>
                            <div class="task-item">
                                <div>Presentasi Bahasa Inggris</div>
                                <div class="deadline">4 hari lagi</div>
                            </div>
                            <div class="task-item">
                                <div>Project Web</div>
                                <div class="deadline">1 minggu lagi</div>
                            </div>
                        </div>
                        <a href="#" class="btn-link centered" id="link-tugas">Lihat Semua Tugas</a>
                    </div>
                    <div class="card">
                        <div class="card-title">
                            <i class="fas fa-calendar-alt"></i> Jadwal Hari Ini
                        </div>
                        <div class="schedule-list">
                            <div class="schedule-item">
                                <span class="time">08:00 - 09:30</span>
                                <span class="event">Kelas Matematika</span>
                            </div>
                            <div class="schedule-item">
                                <span class="time">10:00 - 11:30</span>
                                <span class="event" >Kelas Bahasa Inggris</span>
                            </div>
                            <div class="schedule-item">
                                <span class="time">13:00 - 14:30</span>
                                <span class="event">Lab Pemrograman</span>
                            </div>
                        </div>
                        <a href="#" class="btn-link centered" id="link-jadwal">Lihat Jadwal Lengkap</a>
                    </div>
            `;
            break;

        case "kursus":
            content = `
                <h1>Kursus yang Diikuti</h1>
                <div class="course-list">
                    <div class="course-item">
                        <div>Matematika Dasar</div>
                        <div class="progress-bar">
                            <div class="progress" style="width: 75%"></div>
                        </div>
                        <div class="course-details">
                            <span>75% Selesai</span>
                            <a href="#" class="btn-small" onclick="loadPage('kursus-matematika')">Lanjutkan</a>
                        </div>
                    </div>
                    <div class="course-item">
                        <div>Bahasa Inggris</div>
                        <div class="progress-bar">
                            <div class="progress" style="width: 60%"></div>
                        </div>
                        <div class="course-details">
                            <span>60% Selesai</span>
                            <a href="#" class="btn-small" onclick="loadPage('kursus-bahasa-inggris')">Lanjutkan</a>
                        </div>
                    </div>
                    <div class="course-item">
                        <div>Pemrograman Web</div>
                        <div class="progress-bar">
                            <div class="progress" style="width: 40%"></div>
                        </div>
                        <div class="course-details">
                            <span>40% Selesai</span>
                            <a href="#" class="btn-small" onclick="loadPage('kursus-pemrograman-web')">Lanjutkan</a>
                        </div>
                    </div>
                </div>
            `;
            break;

        case "tugas":
            content = `
                    <h1>Pemberitahuan Tugas</h1>
                    <div class="assignment-list">
                        <div class="assignment-item">
                            <div class="assignment-title">Tugas 1: Matematika Dasar</div>
                            <div class="assignment-due-date">Jatuh Tempo: <span style="color:red;">20 Oktober 2024</span></div>
                            <button class="btn-selesaikan" onclick="loadPage('selesaikan-tugas-matematika')">Selesaikan</button>
                        </div>
                        <div class="assignment-item">
                            <div class="assignment-title">Tugas 2: Bahasa Inggris</div>
                            <div class="assignment-due-date">Jatuh Tempo: <span style="color:red;">22 Oktober 2024</span></div>
                            <button class="btn-selesaikan" onclick="loadPage('selesaikan-tugas-inggris')">Selesaikan</button>
                        </div>
                        <div class="assignment-item">
                            <div class="assignment-title">Tugas 3: Pemrograman Web</div>
                            <div class="assignment-due-date">Jatuh Tempo: <span style="color:red;">25 Oktober 2024</span></div>
                            <button class="btn-selesaikan" onclick="loadPage('selesaikan-tugas-web')">Selesaikan</button>
                        </div>
                    </div>
                `;
            break;

        case "jadwal":
            content = `
                    <h1>Jadwal Kursus</h1>
                    <div class="schedule-list">
                            <div class="schedule-item">
                                <span class="time">08:00 - 09:30</span>
                                <span class="event">Kelas Matematika</span>
                            </div>
                            <div class="schedule-item">
                                <span class="time">10:00 - 11:30</span>
                                <span class="event" >Kelas Bahasa Inggris</span>
                            </div>
                            <div class="schedule-item">
                                <span class="time">13:00 - 14:30</span>
                                <span class="event">Lab Pemrograman</span>
                            </div>
                        </div>
                `;
            break;

        case "kursus-bahasa-inggris":
            content = `
                        <h1>Kursus Bahasa Inggris</h1>
                        <div class="course-container">
                            <div class="course-header">
                                <h2>Bahasa Inggris Dasar</h2>
                                <div class="course-progress">
                                    <div class="progress-bar">
                                        <div class="progress" style="width: 60%"></div>
                                    </div>
                                    <span>60% Selesai</span>
                                </div>
                            </div>
                            <div class="course-content">
                                <h3>Materi Pembelajaran</h3>
                                <ul class="lesson-list">
                                    <li class="completed">
                                        <span class="lesson-title">Pelajaran 1: Pengenalan dan Salam</span>
                                        <span class="lesson-status">Selesai</span>
                                    </li>
                                    <li class="completed">
                                        <span class="lesson-title">Pelajaran 2: Kata Ganti dan Kata Benda</span>
                                        <span class="lesson-status">Selesai</span>
                                    </li>
                                    <li class="in-progress">
                                        <span class="lesson-title">Pelajaran 3: Kata Kerja Dasar</span>
                                        <button class="btn-lanjutkan">Lanjutkan</button>
                                    </li>
                                    <li>
                                        <span class="lesson-title">Pelajaran 4: Membentuk Kalimat Sederhana</span>
                                        <span class="lesson-status">Belum dimulai</span>
                                    </li>
                                    <li>
                                        <span class="lesson-title">Pelajaran 5: Percakapan Sehari-hari</span>
                                        <span class="lesson-status">Belum dimulai</span>
                                    </li>
                                </ul>
                            </div>
                            <div class="course-resources">
                                <h3>Sumber Daya Tambahan</h3>
                                <ul>
                                    <li><a href="https://www.kamus.net/" class="resource-link">Kamus Online</a></li>
                                    <li><a href="#" class="resource-link">Latihan Pengucapan</a></li>
                                    <li><a href="#" class="resource-link">Forum Diskusi</a></li>
                                </ul>
                            </div>
                        </div>
                    `;
            break;

        case "kursus-matematika":
            content = `
                            <h1>Kursus Matematika</h1>
                            <div class="course-container">
                                <div class="course-header">
                                    <h2>Matematika Dasar</h2>
                                    <div class="course-progress">
                                        <div class="progress-bar">
                                            <div class="progress" style="width: 75%"></div>
                                        </div>
                                        <span>75% Selesai</span>
                                    </div>
                                </div>
                                <div class="course-content">
                                    <h3>Materi Pembelajaran</h3>
                                    <ul class="lesson-list">
                                        <li class="completed">
                                            <span class="lesson-title">Pelajaran 1: Pengenalan Aljabar</span>
                                            <span class="lesson-status">Selesai</span>
                                        </li>
                                        <li class="completed">
                                            <span class="lesson-title">Pelajaran 2: Persamaan Linear</span>
                                            <span class="lesson-status">Selesai</span>
                                        </li>
                                        <li class="completed">
                                            <span class="lesson-title">Pelajaran 3: Fungsi dan Grafik</span>
                                            <span class="lesson-status">Selesai</span>
                                        </li>
                                        <li class="in-progress">
                                            <span class="lesson-title">Pelajaran 4: Trigonometri Dasar</span>
                                            <button class="btn-lanjutkan">Lanjutkan</button>
                                        </li>
                                        <li>
                                            <span class="lesson-title">Pelajaran 5: Kalkulus Pengantar</span>
                                            <span class="lesson-status">Belum dimulai</span>
                                        </li>
                                    </ul>
                                </div>
                                <div class="course-resources">
                                    <h3>Sumber Daya Tambahan</h3>
                                    <ul>
                                        <li><a href="https://www.desmos.com/calculator?lang=id" class="resource-link">Kalkulator Grafik Online</a></li>
                                        <li><a href="https://tirto.id/soal-trigonometri-kelas-10-semester-2-beserta-jawaban-pembahasan-gLoG" class="resource-link">Bank Soal Latihan Trigonometri</a></li>
                                        <li><a href="https://www.youtube.com/watch?v=U_6ZrHgPb_c" class="resource-link">Video Tutorial Aljabar</a></li>
                                    </ul>
                                </div>
                            </div>
                        `;
            break;

        case "kursus-pemrograman-web":
            content = `
                                <h1>Kursus Pemrograman Web</h1>
                                <div class="course-container">
                                    <div class="course-header">
                                        <h2>Dasar Pemrograman Web</h2>
                                        <div class="course-progress">
                                            <div class="progress-bar">
                                                <div class="progress" style="width: 40%"></div>
                                            </div>
                                            <span>40% Selesai</span>
                                        </div>
                                    </div>
                                    <div class="course-content">
                                        <h3>Materi Pembelajaran</h3>
                                        <ul class="lesson-list">
                                            <li class="completed">
                                                <span class="lesson-title">Pelajaran 1: Pengenalan HTML</span>
                                                <span class="lesson-status">Selesai</span>
                                            </li>
                                            <li class="completed">
                                                <span class="lesson-title">Pelajaran 2: CSS Dasar</span>
                                                <span class="lesson-status">Selesai</span>
                                            </li>
                                            <li class="in-progress">
                                                <span class="lesson-title">Pelajaran 3: JavaScript Fundamental</span>
                                                <button class="btn-lanjutkan">Lanjutkan</button>
                                            </li>
                                            <li>
                                                <span class="lesson-title">Pelajaran 4: Responsive Web Design</span>
                                                <span class="lesson-status">Belum dimulai</span>
                                            </li>
                                            <li>
                                                <span class="lesson-title">Pelajaran 5: Pengenalan Backend dengan Node.js</span>
                                                <span class="lesson-status">Belum dimulai</span>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="course-resources">
                                        <h3>Sumber Daya Tambahan</h3>
                                        <ul>
                                            <li><a href="#" class="resource-link">Code Editor Online</a></li>
                                            <li><a href="#" class="resource-link">Dokumentasi Web MDN</a></li>
                                            <li><a href="#" class="resource-link">Forum Diskusi Pengembang</a></li>
                                        </ul>
                                    </div>
                                </div>
                            `;
            break;

        case "selesaikan-tugas-matematika":
            content = `
                                        <h1>Tugas Matematika</h1>
                                        <div class="task-completion-container">
                                        <form id="task-completion-form">
                                            <div class="form-group">
                                                <label for="task-file">Unggah File Tugas:</label>
                                                <input type="file" id="task-file" name="task-file" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="task-comments">Komentar (opsional):</label>
                                                <textarea id="task-comments" name="task-comments" rows="4"></textarea>
                                            </div>
                                            <div class="form-group">
                                                <button type="submit" class="btn-submit">Kirim Tugas</button>
                                            </div>
                                        </form>
                                    </div>
                                    `;

            setTimeout(() => {
                const form = document.getElementById("task-completion-form");
                form.addEventListener("submit", (e) => {
                    e.preventDefault();
                    alert("Tugas berhasil dikirim!");
                    loadPage("tugas");
                });
            }, 0);
            break;

        case "selesaikan-tugas-inggris":
            content = `
                                        <h1>Tugas Bahasa Inggris</h1>
                                        <div class="task-completion-container">
                                        <form id="task-completion-form">
                                            <div class="form-group">
                                                <label for="task-file">Unggah File Tugas:</label>
                                                <input type="file" id="task-file" name="task-file" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="task-comments">Komentar (opsional):</label>
                                                <textarea id="task-comments" name="task-comments" rows="4"></textarea>
                                            </div>
                                            <div class="form-group">
                                                <button type="submit" class="btn-submit">Kirim Tugas</button>
                                            </div>
                                        </form>
                                    </div>
                                    `;

            setTimeout(() => {
                const form = document.getElementById("task-completion-form");
                form.addEventListener("submit", (e) => {
                    e.preventDefault();
                    alert("Tugas berhasil dikirim!");
                    loadPage("tugas");
                });
            }, 0);
            break;

        case "selesaikan-tugas-web":
            content = `
                                        <h1>Tugas Pemrograman Web</h1>
                                        <div class="task-completion-container">
                                        <form id="task-completion-form">
                                            <div class="form-group">
                                                <label for="task-file">Unggah File Tugas:</label>
                                                <input type="file" id="task-file" name="task-file" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="task-comments">Komentar (opsional):</label>
                                                <textarea id="task-comments" name="task-comments" rows="4"></textarea>
                                            </div>
                                            <div class="form-group">
                                                <button type="submit" class="btn-submit">Kirim Tugas</button>
                                            </div>
                                        </form>
                                    </div>
                                    `;

            setTimeout(() => {
                const form = document.getElementById("task-completion-form");
                form.addEventListener("submit", (e) => {
                    e.preventDefault();
                    alert("Tugas berhasil dikirim!");
                    loadPage("tugas");
                });
            }, 0);
            break;

        case "profil":
            content = `
                                            <h1>Profil Siswa</h1>
                                            <div class="profile-container">
                                                <div class="profile-header">
                                                    <img src="Nur Asysyifa_21SA1005.jpg" alt="Foto Profil" class="profile-picture">
                                                    <h2>Nur Asysyifa Febriyanti</h2>
                                                    <p>NIM: 21SA1005</p>
                                                </div>
                                                <div class="profile-details">
                                                    <h3>Informasi Pribadi</h3>
                                                    <p><strong>Email:</strong> nurasysyifaf18@gmail.com</p>
                                                    <p><strong>Program Studi:</strong> Informatika</p>
                                                    <p><strong>Angkatan:</strong> 2021</p>
                                                    <p><strong>Status:</strong> Aktif</p>
                                                </div>
                                                <div class="profile-actions">
                                                    <button class="btn-primary">Edit Profil</button>
                                                    <button class="btn-secondary">Ganti Password</button>
                                                </div>
                                            </div>
                                        `;
            break;

        case "diskusi":
            content = `
                                            <h1>Forum Diskusi</h1>
                                            <div class="discussion-container">
                                                <div class="discussion-header">
                                                    <input type="text" placeholder="Cari topik diskusi..." class="search-input">
                                                    <button class="btn-primary" id="new-topic-btn">Buat Topik Baru</button>
                                                </div>
                                                <div class="discussion-list">
                                                    <div class="discussion-item">
                                                        <h3>Pertanyaan tentang Algoritma Sorting</h3>
                                                        <p class="discussion-meta">Oleh: John Doe | 2 hari yang lalu | 5 balasan</p>
                                                        <p class="discussion-excerpt">Saya memiliki pertanyaan tentang kompleksitas waktu dari algoritma QuickSort...</p>
                                                        <a href="#" class="btn-link">Baca Selengkapnya</a>
                                                    </div>
                                                    <div class="discussion-item">
                                                        <h3>Tips Belajar Efektif untuk Ujian</h3>
                                                        <p class="discussion-meta">Oleh: Jane Smith | 1 minggu yang lalu | 12 balasan</p>
                                                        <p class="discussion-excerpt">Berikut adalah beberapa tips yang saya gunakan untuk belajar efektif...</p>
                                                        <a href="#" class="btn-link">Baca Selengkapnya</a>
                                                    </div>
                                                    <!-- More discussion items can be added here -->
                                                </div>
                                                <div class="pagination">
                                                    <a href="#" class="btn-link">Sebelumnya</a>
                                                    <span>Halaman 1 dari 5</span>
                                                    <a href="#" class="btn-link">Selanjutnya</a>
                                                </div>
                                            </div>
                                        `;
            break;

        default:
            content = `<h1>Halaman Tidak Ditemukan</h1>`;
            break;
    }

    contentDiv.innerHTML = content;

    const tugasLink = document.getElementById("link-tugas");
    if (tugasLink) {
        tugasLink.addEventListener("click", (event) => {
            event.preventDefault();
            loadPage("tugas");
        });
    }

    const kursusLink = document.getElementById("link-kursus");
    if (kursusLink) {
        kursusLink.addEventListener("click", (event) => {
            event.preventDefault();
            loadPage("kursus");
        });
    }

    const diskusiLink = document.getElementById("link-diskusi");
    if (diskusiLink) {
        diskusiLink.addEventListener("click", (event) => {
            event.preventDefault();
            loadPage("kursus");
        });
    }

    const profilLink = document.getElementById("link-profil");
    if (profilLink) {
        profilLink.addEventListener("click", (event) => {
            event.preventDefault();
            loadPage("kursus");
        });
    }

    const jadwalLink = document.getElementById("link-jadwal");
    if (jadwalLink) {
        jadwalLink.addEventListener("click", (event) => {
            event.preventDefault();
            loadPage("jadwal");
        });
    }
}
