const sidebar = document.querySelector(".sidebar");
const mainContent = document.querySelector(".main-content");
const sidebarToggle = document.querySelector(".sidebar-toggle");
const toggleIcon = sidebarToggle.querySelector("i");
const mobileMenuBtn = document.querySelector(".mobile-menu-btn");
const navItems = document.querySelectorAll(".nav-item");
const contentDiv = document.getElementById("content");

function toggleSidebar() {
  sidebar.classList.toggle("collapsed");
  mainContent.classList.toggle("expanded");
  toggleIcon.classList.toggle("fa-chevron-left");
  toggleIcon.classList.toggle("fa-chevron-right");
}

sidebarToggle.addEventListener("click", toggleSidebar);

mobileMenuBtn.addEventListener("click", () => {
  sidebar.classList.toggle("mobile-active");
});

document.addEventListener("click", (e) => {
  if (
    window.innerWidth <= 768 &&
    !sidebar.contains(e.target) &&
    !mobileMenuBtn.contains(e.target) &&
    sidebar.classList.contains("mobile-active")
  ) {
    sidebar.classList.remove("mobile-active");
  }
});

function animateProgressBars() {
  const progressBars = document.querySelectorAll(".progress");
  progressBars.forEach((bar) => {
    const width = bar.getAttribute("data-width") || "0";
    bar.style.width = "0";
    setTimeout(() => {
      bar.style.width = width;
    }, 100);
  });
}

const progressBars = document.querySelectorAll(".progress");
progressBars.forEach((bar) => {
  const width = bar.style.width;
  bar.style.width = "0";
  setTimeout(() => {
    bar.style.width = width;
  }, 100);
});

navItems.forEach((item) => {
  item.addEventListener("click", (e) => {
    e.preventDefault();
    const page = item.getAttribute("data-page");
    loadPage(page);

    if (window.innerWidth <= 768) {
      sidebar.classList.remove("mobile-active");
    }
  });
});

document.addEventListener("DOMContentLoaded", () => loadPage("beranda"));
