Buka page awal pada dashboard.html
